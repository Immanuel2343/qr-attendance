# QR Code Attendance System

## Quick Start

1. Install Node.js from https://nodejs.org (LTS version)
2. Open a terminal in this folder and run:
   ```
   npm install
   node server.js
   ```
3. Terminal will print two URLs — open the **Network** one on your phone to test

## Teacher flow
- Open `http://localhost:3000` on laptop
- Type subject name → Start Session
- QR code appears → project it on screen
- It auto-rotates every 20s (stops screenshot sharing)
- Open Dashboard tab to see attendance live

## Student flow (phone)
1. Open phone camera → point at QR code
2. A link appears — tap it → browser opens the scan page
3. Type name + roll number (optional) → Confirm
4. Done — appears on teacher's dashboard instantly

> ⚠️ Laptop and phone must be on the **same WiFi network**.
> If the QR doesn't open a link, type the Network URL shown below the QR manually in the phone browser.

## Files
- `server.js` — Node/Express backend
- `public/index.html` — Teacher panel (start session, QR display)
- `public/scan.html` — Student check-in (name input + confirm)
- `public/dashboard.html` — Live attendance log + CSV export
- `public/style.css` — Shared styles
