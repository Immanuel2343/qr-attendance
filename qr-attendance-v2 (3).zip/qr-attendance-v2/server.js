const express = require('express');
const QRCode = require('qrcode');
const { nanoid } = require('nanoid');
const path = require('path');
const os = require('os');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

function getBaseUrl() {
  // On Render (and most cloud hosts) the public URL is set as an env variable
  if (process.env.RENDER_EXTERNAL_URL) return process.env.RENDER_EXTERNAL_URL;
  // Local fallback — use LAN IP so phone on same WiFi can reach it
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) return `http://${net.address}:${PORT}`;
    }
  }
  return `http://localhost:${PORT}`;
}

// ---- Data ----
let currentSession = null;
const attendance = {};
const QR_ROTATE_MS = 20000;

function rotateToken(session) {
  session.token = nanoid(10);
  session.tokenExpiresAt = Date.now() + QR_ROTATE_MS;
}

// Start session
app.post('/api/session/start', (req, res) => {
  const { subject } = req.body;
  const id = nanoid(8);
  currentSession = { id, subject: subject || 'Class Session', createdAt: Date.now() };
  rotateToken(currentSession);
  attendance[id] = {};
  res.json({ sessionId: id });
});

// End session
app.post('/api/session/end', (req, res) => {
  currentSession = null;
  res.json({ ok: true });
});

// Get QR — encodes a PLAIN URL (no JSON) so phone cameras open it directly
app.get('/api/session/qr', async (req, res) => {
  if (!currentSession) return res.status(404).json({ error: 'No active session' });
  if (Date.now() > currentSession.tokenExpiresAt) rotateToken(currentSession);

  const base = getBaseUrl();
  const scanUrl = `${base}/scan.html?sid=${currentSession.id}&tok=${currentSession.token}`;

  const dataUrl = await QRCode.toDataURL(scanUrl, {
    margin: 2,
    width: 320,
    errorCorrectionLevel: 'H',          // highest — cameras scan more reliably
    color: { dark: '#000000', light: '#ffffff' }
  });

  res.json({
    dataUrl,
    scanUrl,
    expiresInMs: currentSession.tokenExpiresAt - Date.now(),
    subject: currentSession.subject,
    sessionId: currentSession.id,
  });
});

// Mark attendance — receives name + rollNo from the scan page
app.post('/api/attendance/mark', (req, res) => {
  const { sid, tok, studentName, rollNo } = req.body;

  if (!studentName || !studentName.trim())
    return res.status(400).json({ error: 'Please enter your name.' });

  if (!currentSession || sid !== currentSession.id)
    return res.status(400).json({ error: 'Session not found or already ended.' });

  if (tok !== currentSession.token)
    return res.status(400).json({ error: 'QR code expired — please scan the latest code on screen.' });

  const key = (rollNo ? rollNo.trim().toUpperCase() : studentName.trim().toLowerCase());

  if (attendance[currentSession.id][key]) {
    return res.json({ status: 'already-marked', name: attendance[currentSession.id][key].name });
  }

  const time = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  attendance[currentSession.id][key] = {
    name: studentName.trim(),
    rollNo: rollNo ? rollNo.trim().toUpperCase() : '—',
    time,
  };

  res.json({ status: 'marked', name: studentName.trim(), time });
});

// Dashboard data
app.get('/api/dashboard', (req, res) => {
  if (!currentSession) return res.json({ active: false });
  const present = attendance[currentSession.id] || {};
  const rows = Object.values(present).sort((a, b) => a.name.localeCompare(b.name));
  res.json({
    active: true,
    subject: currentSession.subject,
    sessionId: currentSession.id,
    present: rows.length,
    students: rows,
  });
});

app.listen(PORT, () => {
  console.log(`\n✅ QR Attendance System running`);
  console.log(`   Local  : http://localhost:${PORT}`);
  console.log(`   Public : ${getBaseUrl()}\n`);
});
